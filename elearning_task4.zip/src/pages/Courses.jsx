import React from 'react';
import { Link } from 'react-router-dom';
import courses from '../sampleData';

export default function Courses(){
  return (
    <div>
      <h2>All Courses</h2>
      <div className="grid">
        {courses.map(c => (
          <div className="card" key={c.id}>
            <h3 className="course-title">{c.title}</h3>
            <p className="meta">{c.description}</p>
            <div className="meta">Duration: {c.duration}</div>
            <Link to={`/courses/${c.id}`} className="btn">Open Course</Link>
          </div>
        ))}
      </div>
    </div>
  );
}
