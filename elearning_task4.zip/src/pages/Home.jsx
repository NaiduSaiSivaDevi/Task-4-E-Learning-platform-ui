import React from 'react';
import { Link } from 'react-router-dom';

export default function Home(){
  return (
    <div>
      <section className="hero card">
        <h1>Welcome to CodTech E-Learning UI</h1>
        <p className="meta">Browse courses, track progress, and watch embedded lessons.</p>
        <Link to="/courses" className="btn">Explore Courses</Link>
      </section>

      <section className="section">
        <h2>Featured Courses</h2>
        <div className="grid">
          <div className="card">
            <h3 className="course-title">Front-End Fundamentals</h3>
            <p className="meta">HTML, CSS, and JavaScript basics</p>
            <Link to="/courses/1" className="btn">View Course</Link>
          </div>
          <div className="card">
            <h3 className="course-title">React for Beginners</h3>
            <p className="meta">Build single-page applications with React</p>
            <Link to="/courses/2" className="btn">View Course</Link>
          </div>
          <div className="card">
            <h3 className="course-title">UI Design Essentials</h3>
            <p className="meta">Principles of modern UI design</p>
            <Link to="/courses/3" className="btn">View Course</Link>
          </div>
        </div>
      </section>
    </div>
  );
}
