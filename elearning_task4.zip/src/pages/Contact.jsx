import React from 'react';

export default function Contact(){
  return (
    <div className="card">
      <h2>Contact</h2>
      <p>If you'd like to collaborate or learn together, reach out:</p>
      <ul>
        <li>Email: <a href="mailto:naidusaisivadevi@gmail.com">naidusaisivadevi@gmail.com</a></li>
        <li>GitHub: <a href="https://github.com/NaiduSaiSivaDevi" target="_blank">github.com/NaiduSaiSivaDevi</a></li>
        <li>LinkedIn: <a href="https://www.linkedin.com/in/sai-siva-devi-naidu-634624291" target="_blank">linkedin.com/in/sai-siva-devi-naidu-634624291</a></li>
      </ul>
    </div>
  );
}
