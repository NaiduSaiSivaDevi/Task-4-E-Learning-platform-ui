import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import courses from '../sampleData';

export default function CourseDetail(){
  const { id } = useParams();
  const course = courses.find(c => String(c.id) === id);
  const storageKey = `progress_course_${id}`;
  const [progress, setProgress] = useState(() => {
    const saved = localStorage.getItem(storageKey);
    return saved ? Number(saved) : 0;
  });

  useEffect(() => {
    localStorage.setItem(storageKey, String(progress));
  }, [progress]);

  if(!course) return <div className="card">Course not found</div>;

  return (
    <div>
      <div className="card">
        <h2>{course.title}</h2>
        <p className="meta">{course.description}</p>
        <div className="meta">Duration: {course.duration}</div>

        <div style={{marginTop:12}}>
          <h3>Lesson Video</h3>
          <div style={{position:'relative',paddingTop:'56.25%'}}>
            <iframe title="lesson" src={course.video} style={{position:'absolute',top:0,left:0,width:'100%',height:'100%'}} frameBorder="0" allowFullScreen></iframe>
          </div>
        </div>

        <div className="progress" aria-label="Course progress">
          <div className="progress-bar" style={{width:progress + '%'}}></div>
        </div>

        <div style={{marginTop:12}}>
          <button className="btn" onClick={() => setProgress(p => Math.min(100, p + 10))}>Mark +10%</button>
          <button className="btn" style={{marginLeft:8}} onClick={() => setProgress(p => Math.max(0, p - 10))}>-10%</button>
        </div>
      </div>
    </div>
  );
}
