const courses = [
  {
    id: 1,
    title: 'Front-End Fundamentals',
    description: 'HTML, CSS, and JavaScript basics',
    duration: '3 hours',
    video: 'https://www.youtube.com/embed/UB1O30fR-EE' // sample video (HTML crash course)
  },
  {
    id: 2,
    title: 'React for Beginners',
    description: 'Build single-page applications with React',
    duration: '4 hours',
    video: 'https://www.youtube.com/embed/Ke90Tje7VS0' // sample React tutorial
  },
  {
    id: 3,
    title: 'UI Design Essentials',
    description: 'Principles of modern UI design and best practices',
    duration: '2.5 hours',
    video: 'https://www.youtube.com/embed/9g3X1wJ0eC4' // sample UI design video
  }
];

export default courses;
