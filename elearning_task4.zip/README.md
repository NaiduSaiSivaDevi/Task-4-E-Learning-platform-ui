# Task 4 — E-Learning Platform UI (CodTech Internship)

This is a React-based front-end UI for an e-learning platform built for CodTech Task 4.
It includes a homepage, course listings, course detail page with video embedding, and simple progress tracking stored in localStorage.

## How to run (development)
1. Install Node.js (v16+) and npm.
2. In the project root, install dependencies and run:
   ```bash
   npm install
   npm run dev
   ```
3. Open the Vite dev server URL (usually http://localhost:5173).

## Features
- React + React Router multi-page UI
- Course listing and detail pages
- Video embedding using iframe (YouTube sample links)
- Progress tracking (stored in localStorage) with +10% / -10% controls
- Responsive layout and navigation

## Personal Info included
- **Name:** Naidu Sai Siva Devi
- **College:** Ramachandra College of Engineering (A), Eluru
- **Course:** B.Tech – 3rd Year, CSE
- **Email:** naidusaisivadevi@gmail.com
- **GitHub:** https://github.com/NaiduSaiSivaDevi
- **LinkedIn:** https://www.linkedin.com/in/sai-siva-devi-naidu-634624291

Built for CodTech Internship — Task 4.
